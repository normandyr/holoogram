package com.missouristate.bryson.holoogram

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.facebook.AccessToken
import com.facebook.GraphRequest
import com.facebook.GraphResponse
import com.facebook.HttpMethod
import com.facebook.internal.Mutable
import org.json.JSONObject


private const val AccessTokenForIntent = "Access Token"

private lateinit var currentUser: User
private lateinit var accessToken: AccessToken
private lateinit var request: GraphRequest

val friendsMap: MutableMap<String, String> = HashMap()

class HomepageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homepage)
        //var accessToken = intent.getSerializableExtra(AccessTokenForIntent)
        /* make the API call */

        request = GraphRequest(
            AccessToken.getCurrentAccessToken(),
            "/{person-id}/",
            null,
            HttpMethod.GET,
            GraphRequest.Callback {

                fun onCompleted(response: GraphResponse) {
                    var jGraphObj: JSONObject? = response.jsonObject
                    /* handle the result */
                    //TODO: Figure this crap out
                    try {
                        val friendsData = jGraphObj!!.getJSONArray("data")
                        for (i in 0 until friendsData.length()) {
                            val friend = friendsData.getJSONObject(i)
                            val friendId = friend.getString("id")
                            val friendName = friend.getString("name")
                            friendsMap[friendId] = friendName
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        )
        //request.executeAsync()
        //line below throws and error
        //request.executeAndWait()
        //https://stackoverflow.com/questions/35905498/facebook-api-how-to-wait-til-graphrequest-executeasync-is-done
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.contact_us_a_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.contact -> {
                val intent = Intent(this, ContactUs::class.java)
                startActivity(intent)
            }


        }
        return super.onOptionsItemSelected(item)
    }
}
