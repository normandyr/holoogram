package com.missouristate.bryson.holoogram

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.vision.Frame
import com.google.android.gms.vision.barcode.Barcode
import com.google.android.gms.vision.barcode.BarcodeDetector


class ContactUsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)
    }

    fun sendEmail(v: View) {
        var userName: String = findViewById<EditText>(R.id.editText_FullName_Contact).text.toString()
        val mailto = "mailto:bryson.atom@gmail.com" +
                "?cc=" + "" +
                "&subject=" + Uri.encode("Support Needed") +
                "&body=" + Uri.encode("From: $userName")

        val emailIntent = Intent(Intent.ACTION_SENDTO)
        emailIntent.type = "text/plain";
        emailIntent.type = "message/rfc822"
        emailIntent.data = Uri.parse(mailto)

        try {
            startActivity(emailIntent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No email clients installed.", Toast.LENGTH_SHORT).show()
        }


    }
}