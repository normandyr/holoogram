package com.missouristate.bryson.holoogram

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.facebook.AccessToken
import com.facebook.GraphRequest
import com.facebook.GraphResponse
import com.facebook.HttpMethod
import org.json.JSONObject
import java.util.*

private const val AccessTokenForIntent = "Access Token"

private lateinit var currentUser: User
private lateinit var accessToken: AccessToken
private lateinit var request: GraphRequest

class HomepageActivityA : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_a)
        //var accessToken = intent.getSerializableExtra(AccessTokenForIntent)
        /* make the API call */
        request = GraphRequest(
            AccessToken.getCurrentAccessToken(),
            "/{person-id}/",
            null,
            HttpMethod.GET,
            GraphRequest.Callback { /* handle the result */
                //TODO: Figure this crap out
            }
        )
        //request.executeAsync()
        //line below throws and error
        //request.executeAndWait()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.contact_us_a_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.contact -> {
                val intent = Intent(this, ContactUsA::class.java)
                startActivity(intent)
            }


        }
        return super.onOptionsItemSelected(item)
    }
}
