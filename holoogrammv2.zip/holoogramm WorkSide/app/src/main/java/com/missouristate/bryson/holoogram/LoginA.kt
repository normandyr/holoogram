package com.missouristate.bryson.holoogram

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity



class LoginA: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_a)

        val createBtn: Button = findViewById(R.id.CreateActID)
        val lgnBtn: Button = findViewById(R.id.LoginID)

        createBtn.setOnClickListener {
            val intent = Intent(this, SignupActivityA::class.java)
            startActivity(intent)

        }

        lgnBtn.setOnClickListener {
            val intent = Intent(this, HomepageActivityA::class.java)
            startActivity(intent)

        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.contact_us_a_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.contact -> {
                val intent = Intent(this, ContactUsA::class.java)
                startActivity(intent)
            }


        }
        return super.onOptionsItemSelected(item)
    }

}